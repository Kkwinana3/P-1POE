/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.part1poe;

/**
 *
 * @author Student
 */
import java.util.Scanner;

public class Part1poe{
    public static void main(String[] args){
        
        Scanner scanner = new Scanner(System.in);
        
        String username;
        String password;
        String cellphone;
        
        System.out.println("Enter your username: ");
        username = scanner.nextLine();
        while(!validatesUsername(username)){
            System.out.println("RE-Enter your username: ");
            username = scanner.nextLine();
            
        }
        System.out.println("Enter your password: ");
        password = scanner.nextLine();
        while(!validatePassword(password)){
            System.out.println("Re-Enter your password: ");
            password = scanner.nextLine();
            
        }
        System.out.println("Enter your cellphone number: ");
        cellphone = scanner.nextLine();
        while(!validateCellphone(cellphone)){
            System.out.println("Re-Enter your cellphone number:");
            
        }
        scanner.close();
        
    }

    //username and password validation
    public static boolean validateUsername(String name) {
        if(name.length()>=5 && !name.contains("_")){
            System.out.println("user must be at least 5 characters long and contain an (_)");
            return false;
        }else{
            System.out.println("username successfully captured. ");
        }
        return true;
    }
    
public static boolean validatePassowrd(String password){
    if (password.length()>=8){
        System.out.println("Password must be at least 8 characters long. ");
        return false;
    }else if (!password.matches(".*[A_Z].*")){
        System.out.println("Password must contain at least one uppercase.");
        return false;
    }else if (!password.matches(".*[0-8].*")){
        System.out.println("Password must contain at least one number.");
        return false;
    }else if (!password.matches(".*[!@#$%&*()]")){
        System.out.println("password must contain at least one special character.");
        return false;
    }else {
        System.out.println("Password successfuly captured.");
    }
    return true;
}
//cellphone number validation 
public static boolean validatesCellphone(String cellphone){
    if (!cellphone.matches("^\\+27\\d{9}")){
        System.out.println("Cellphone number must be in format +27 followed by 9 digits.");
        return false;
    } else {
        System.out.println("Cellphone number successfully captured.");
        return true;
    }
  }

    private static boolean validatesUsername(String username) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static boolean validateCellphone(String cellphone) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static boolean validatePassword(String password) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

    
    

    
