/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.part1poe;

/**
 *
 * @author Student
 */
import java.util.ArrayList;
import java.util.Scanner;
import static javax.swing.text.html.HTML.Tag.U;

public class Login {

    private static boolean checkpasswordcomplexity(String p) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static boolean checkcellPhoneNumber(String c) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static boolean checkUsername(String u) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
  private String authUser;
  private String authPass;
  private static ArrayList<Login> activeRecords= new ArrayList<>();
  
  public Login(String u,String p){
      this.authUser = u;
      this.authPass = p;
  }
  
  public static void main (String[] args){
      Scanner console = new Scanner(System.in);
      System.out.println("Welcome to Login System");
      
      while (true){
          System.out.print("\n1)Register\n2)Log\n3)Exit\nPick");
          String op = console.nextLine().trim();
          
          if(op.equals("1")){
              processLogin(console);
          }else if(op.equals("2")){
              processLog(console);
          }else if (op.equals("3")|| op.equalsIgnoreCase("exit")){
             System.out.println("Exit the System. Good Bye!");
             break;
          }else{
              System.out.println("Invalid choice.Please enter 1,2,or3.");
          }
      }
   
  }
  private static void processLogin(Scanner sc){
      System.out.println("\n--User Signup--");
      System.out.println("Enter your name");
      String u = sc.nextLine();
      while(!Login.checkUsername(u))u=sc.nextLine();
      
      System.out.println("Enter cell (+27): ");
      String c= sc.nextLine();
      while(!Login.checkcellPhoneNumber(c))c=sc.nextLine();
      
      System.out.println("Create password");
      String p = sc.nextLine();
      while(!Login.checkpasswordcomplexity(p)) p = sc.nextLine();
      
      System.out.println("Login successfuly! ");
      
  }
  
private static void processLog(Scanner sc){
    if (activeRecords.isEmpty()){
        System.out.println("Login succesfuly! Welcome," +U+ ". ");
    }else{
        System.out.println("Login failed. Invalid credentials.");
    }
}
}
 



  
    

        